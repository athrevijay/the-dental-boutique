THE DENTAL BOUTIQUE – FREE WEBSITE

Files:
- index.html: complete responsive website. No paid software or backend required.

To publish for free:
1. Create a free account on GitHub.
2. Create a new repository (for example: the-dental-boutique).
3. Upload index.html.
4. In Settings → Pages, choose Deploy from branch → main → /root.
5. GitHub will provide a free website address.

The WhatsApp appointment buttons open:
https://wa.me/918248106482

You can later connect a custom domain such as www.thedentalboutique.in if desired.
